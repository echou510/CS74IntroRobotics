import numpy as np

T45 = np.radians(45)
R = [[0, 1, 0],
     [0, 0, 1],
     [1, 0, 0]]

R45 =[[np.cos(T45), -np.sin(T45), 0],
      [np.sin(T45), np.cos(T45), 0], 
      [0, 0, 1]]
R = np.array(R)
R45 = np.array(R45)
print(R45)
V = np.array([[0], [0], [1]])
R0_1 = np.dot(R45, R)
print(R0_1)
U = np.dot(R0_1, V)
print(U)
