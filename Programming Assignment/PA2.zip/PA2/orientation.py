import numpy as np

R = [[0, 1, 0],
     [0, 0, 1],
     [1, 0, 0]]

R = np.array(R)
V = np.array([[0], [0], [1]])
print(R)
print(V)

VT = V.T[0]

print(VT)

U = np.dot(R, V)
print("Regular Operation:\n", U)

W = np.dot(VT, R.T)
print("Row Vector:\n", W)
