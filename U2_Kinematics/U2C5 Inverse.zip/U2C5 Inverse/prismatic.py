from pylab import *
import numpy as np

a1 = 1
a3 = 1

x = np.linspace(-1, 1, 101)
z = [2.0 for i in range(0, 101)]
r = [np.sqrt(a3**2-x[i]**2) for i in range(0, 101)]
d = [z[i] - a1 - r[i] for i in range(0, 101)]
T = [arccos(r[i]) for i in range(0, 101)]  # r/1 = r
figure()
plot(x, T, 'b')
plot(x, d, 'r')
show()



