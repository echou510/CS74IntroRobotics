from pylab import *
import numpy as np

a2 = 1
a4 = 1
N = 10001
def cosine(a, b, c):
    theta = arccos((a**2+b**2-c**2)/(2*a*b))
    return theta

x = []
y = []
for i in range(0, N):
    done = False
    while not done:
        a = random() * 4.01 + -2.0
        while a > 2 :   # 1<=a<=2
            a = random()*4.01 + -2.0
        b = random() * 4.01 + -2.0
        while b > 2 :   # 1<=a<=2
            b = random()*4.01 + -2.0
        r1 = np.sqrt(a**2+b**2)       # distance to (0, 0)
        #if (r1<=2 and a>=0 and b>=0):  # Quadrant 1 only
        if (r1 <=2):
            x.append(a)
            y.append(b)
            done = True

r = [np.sqrt(x[i]**2 + y[i]**2) for i in range(0, N)]
Phi_1 = [cosine(a2, r[i], a4) for i in range(0, N)]
Phi_2 = [arctan(y[i]/x[i]) for i in range(0, N)]
Phi_3 = [cosine(a2, a4, r[i]) for i in range(0, N)]
T1 = [(Phi_2[i]-Phi_1[i])*180/np.pi for i in range(0, N)]
T2 = [(np.pi - Phi_3[i])*180/np.pi for i in range(0, N)]

figure()
#scatter(x, y)
scatter(T1, T2)
#scatter(x, Phi_1)
#scatter(x, Phi_2)
#scatter(x, Phi_3)
#scatter(x, T1)
#scatter(x, T2)
show()



