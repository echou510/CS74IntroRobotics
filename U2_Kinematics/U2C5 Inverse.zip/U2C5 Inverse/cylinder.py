from pylab import *
import numpy as np

a2 = 1
a3 = 1
y = np.linspace(-3, 3, 101)
x = [3 for i in range(len(y))]
r = [np.sqrt(x[i]**2+y[i]**2) for i in range(len(y))]
d = [r[i]-(a2+a3) for i in range(len(y))]
T = [np.arctan(y[i]/x[i]) for i in range(len(y))]

figure()
plot(y, T, 'b')
plot(y, d, 'r') 
show()


