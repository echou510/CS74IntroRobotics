import numpy as np
E = 10

X = 5.0
Y = 0.0
Z = 3.0

a1 = 1
a2 = 1
a3 = 1
a4 = 1
a5 = 1
a6 = 1

d1 = Z -a1 -a2
T2 = np.arctan(Y/X)
d3 = np.sqrt(X**2+Y**2)-a3-a4

R0_6 = [
     [-1.0, 0.0, 0.0], 
     [0.0, -1.0, 0.0],
     [0.0, 0.0, 1.0]
    ]

R0_3 = [
     [-np.sin(T2), 0.0, np.cos(T2)],
     [np.cos(T2), 0.0, np.sin(T2)],
     [0.0, 1.0, 0.0]
    ]

R0_3inv = np.linalg.inv(R0_3)
R3_6 = np.dot(R0_3inv, R0_6)

print("R3_6=", np.matrix(R3_6))


T5 = np.arccos(R3_6[2][2])
T6 = np.arccos(-R3_6[2][0]/np.sin(T5))
T4 = np.arccos(R3_6[1][2]/np.sin(T5))

print("d1=", d1)
print("T2=", T2, "radians")
print("d3=", d3)
print("T4=", T4, "radians")
print("T5=", T5, "radians")
print("T6=", T6, "radians")
