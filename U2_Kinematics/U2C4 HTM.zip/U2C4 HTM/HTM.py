# HTM.py
# author: Dr. Eric Y. Chou
# version: 09/16/2020
#
import numpy as np
E = 10   # round of 10 decimal points

a1 = 1   # length of link a1 in cm
a2 = 1   # length of link a2 in cm
a3 = 1   # length of link a3 in cm
a4 = 1   # length of link a4 in cm

T1=90    # Theta 1 angle in degree
T2=90    # Theta 2 angle in degree

T1 = (T1/180.0)*np.pi  # Theta 1 angle in radians
T2 = (T2/180.0)*np.pi  # Theta 2 angle in radians

# Rotational Matrix
R0_1 = np.array([
    [np.cos(T1), -np.sin(T1), 0],
    [np.sin(T1),  np.cos(T1), 0], 
    [         0,           0, 1]
])
R1_2 = np.array(
    [[np.cos(T2), -np.sin(T2), 0],
    [np.sin(T2),  np.cos(T2), 0], 
    [         0,           0, 1]
])

R0_2 = np.dot(R0_1, R1_2)
R0_2 = np.ndarray.round(R0_2, E)
print("RM R0_2:")
print(R0_2)
print()

# Displacement Vectors
d0_1 = [a2 * np.cos(T1), a2 * (np.sin(T1)), a1]
d0_1 = np.array(d0_1)
d0_1 = d0_1.reshape(3, 1)
d0_1 = np.ndarray.round(d0_1, E)
print("DV d0_1:")
print(d0_1)
print()

d1_2 = [a4 * np.cos(T2), a4 * (np.sin(T2)), a3]
d1_2 = np.array(d1_2)
d1_2 = d1_2.reshape(3, 1)
d1_2 = np.ndarray.round(d1_2, E)
print("DV d1_2:")
print(d1_2)

# Homogeneous Transform Matrix
H0_1 = np.concatenate((R0_1, d0_1), 1)
H0_1 = H0_1.reshape(3, 4)
#print(H0_1)
#print()

H0_1 = np.concatenate((H0_1,[[0, 0, 0, 1]]), 0)
H0_1 = np.ndarray.round(H0_1, E)
#H0_1 = H0_1.reshape(4, 4)
print("HTM H0_1:")
print(H0_1)
print()

H1_2 = np.concatenate((R1_2, d1_2), 1)
H1_2 = np.concatenate((H1_2,[[0, 0, 0, 1]]), 0)
H1_2 = np.ndarray.round(H1_2, E)
print("HTM H1_2:")
print(H1_2)
print()

H0_2 = H0_1.dot(H1_2)
H0_2 = np.ndarray.round(H0_2, E)
print("HTM H0_2:")
print(H0_2)
print()

# Points
p2 = [1, 0, 0]
p2 = np.array(p2)
p2 = p2.reshape(3, 1)
p2 = np.concatenate((p2, [[1]]), 0)
print("p2: ")
print(p2)
print()
p1 = H1_2.dot(p2)
p1 = np.ndarray.round(p1, E)
print("p1: ")
print(p1)
print()
p0 = H0_2.dot(p2)
p0 = np.ndarray.round(p0, E)
print("p0: ")
print(p0)
print()

w = p0[3][0]
c = [p0[i][0]/w for i in [0, 1, 2]]
print("p0 in Cartesian Coordinate:")
print(c)
print()









