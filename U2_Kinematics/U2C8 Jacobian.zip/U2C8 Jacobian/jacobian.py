# jacobian.py
# author: Dr. Eric Y. Chou
# version: 09/16/2020
#
import denavit as dv
import numpy as np
import pprint as pp
E = 10   # round of 10 decimal points

def Jacobian(T, AF, R, D, Type, N, display=True, name="Jacobian:"):    # N degree of freedom
     A = []
     for i in range(N):
          H = dv.DH_HTM(T[i], AF[i], R[i], D[i], display, name="Time "+str(j)+": A["+str(i+1)+"]")
          H = np.ndarray.round(H, E)
          A.append(H)

     TM = []
     TM.append(A[0])
     for i in range(1, N):
          H = np.dot(TM[i-1], A[i])
          H = np.ndarray.round(H, E)
          TM.append(H)
          
     if (display):
          for i in range(N): 
               print("H0_"+str(i+1)+": ")
               print(TM[i])
               print()

     # Calculate Z and OU vectors
     Z0 = np.zeros(3)
     Z0[N] = 1
     Z0 = Z0.reshape(3, 1)
     Z = [Z0]
     OU0 = np.zeros(3)
     OU0 = OU0.reshape(3, 1)
     OU = [OU0]
     for i in range(N):
          TT = TM[i]
          Zi = np.array([TT[0][2], TT[1][2], TT[2][2]])      # column 3
          Zi = Zi.reshape(3, 1)
          Z.append(Zi)
          OUi = np.array([TT[0][3], TT[1][3], TT[2][3]])     # column 4
          OUi = OUi.reshape(3, 1)
          OU.append(OUi)

     #pp.pprint(Z)
     #pp.pprint(OU)

     # Calculate Jacobian
     J = []
     for i in range(N):
          jack = []
          if (Type[i] == 'P'):
               jack = np.append(Z[i], [[0],[0], [0]], 0)
          elif (Type[i] == 'R'):
               diff = OU[len(OU)-1] - OU[i]
               ZT = Z[i].T
               ZT = np.array(ZT[0])
               diffT = diff.T
               diffT = np.array(diffT[0])
               crossP = np.cross(ZT, diffT)
               crossP = crossP.reshape(len(crossP), 1)
               crossP = np.ndarray.round(crossP, E)
               jack = np.append(crossP, Z[i], 0)
          J.append(jack)
     if (display):
          print(name)
          pp.pprint(J)
          print()
          print()
     return J


# Robot Parameters
N = 2        # degree of freedom
M = 5        # data points
deg90  = np.pi * 90/180
deg45  = np.pi * 45/180
Theta1 = np.linspace(0, np.pi, M)    # sequence of theta1
Theta2 = [0 for i in range(M)]    # sequence of theta2
a1     = [1 for i in range(M)]
a2     = [1 for i in range(M)]

pp.pprint(Theta1)

# table
for j in range(M):
     # one time point (Preparation of DV data)
     T = [Theta1[j], Theta2[j]]
     AF = [0, 0]
     R  = [a1[j], a2[j]]
     D  = [0, 0]
     Type = ['R', 'R']    # 'R' for revolute joint 'P' for Prismatic Joint

     # Generation of Jacobian from here. 
     J = Jacobian(T, AF, R, D, Type, N, True, "Jacobian")
     
     

     
          
     
     
