# denavit.py
# author: Dr. Eric Y. Chou
# version: 09/16/2020
#
import numpy as np
E = 10   # round of 10 decimal points

def DH_HTM(T, af, r, d, display=True, name="DH_HTM:"):
     D = np.zeros((4, 4))
     #D = D.reshape(4, 4)
     D[0][0] = np.cos(T)
     D[0][1] = -np.sin(T) * np.cos(af)
     D[0][2] = np.sin(T) * np.sin(af)
     D[0][3] = r * np.cos(T)

     D[1][0] = np.sin(T)
     D[1][1] = np.cos(T) * np.cos(af)
     D[1][2] = - np.cos(T) * np.sin(af)
     D[1][3] = r * np.sin(T)

     D[2][0] = 0
     D[2][1] = np.sin(af)
     D[2][2] = np.cos(af)
     D[2][3] = d

     D[3][0] = 0
     D[3][1] = 0
     D[3][2] = 0
     D[3][3] = 1

     D = np.ndarray.round(D, E)
     if (display):
          print(name)
          print(D)
          print()
     return D

# Robot Parameters
deg90 = np.pi * 90/180
deg45 = np.pi * 45/180
Theta1 = deg90
Theta2 = 0
a1 = 1
a2 = 1
a3 = 1
a4 = 1
d  = 0

# table
T1 = Theta1
T2 = deg90+Theta2
T3 = deg90
AF1 = deg90
AF2 = deg90
AF3 = 0
R1 = a2
R2 = 0
R3 = 0
D1 = a1
D2 = 0
D3 = a3 + a4 + d

# Test 1
DH_HTM1 = DH_HTM(0, 0, 0, 0, name="DH_HTM1: no move")
#print(DH_HTM1)

# Test 2: 90 degree turn on a a1=1, a2=1
DH_HTM2 = DH_HTM(deg90, 0, 1, 1, name="DH_HTM2: 90 turn")

# Test 3: 90 degree turn on a a1=1, a2=1
DH_HTM3 = DH_HTM(deg45, 0, 1, 1, name="DH_HTM3: 45 turn")

H0_1 = DH_HTM(T1, AF1, R1, D1)
H1_2 = DH_HTM(T2, AF2, R2, D2)
H2_3 = DH_HTM(T3, AF3, R3, D3)
H0_2 = np.dot(H0_1, H1_2)
H0_3 = np.dot(H0_2, H2_3)
H0_3 = np.ndarray.round(H0_3, E)
print("H0_3: T1=90, T2=0, arm=3")
print(H0_3)
print()

w = [0, 0, 0, 1]
w = np.array(w)
w = w.reshape(4, 1)
W0_1 = np.dot(H0_1, w)
W0_1 = np.ndarray.round(W0_1, E)
print("W0_1:")
print(W0_1)
print()

W0_2 = np.dot(H0_2, w)
W0_2 = np.ndarray.round(W0_2, E)
print("W0_2:")
print(W0_2)
print()
W0_n = np.dot(H0_3, w)
W0_n = np.ndarray.round(W0_n, E)
print("W0_n:")
print(W0_n)
print()