from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from itertools import product, combinations

#====================================================
I = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
E = 10   # round of 10 decimal points

T1=90   # Theta 1 angle in degree
T2=45    # Theta 2 angle in degree

T1 = (T1/180.0)*np.pi
T2 = (T2/180.0)*np.pi



R0_1 = np.array([
    [np.cos(T1), -np.sin(T1), 0],
    [np.sin(T1),  np.cos(T1), 0], 
    [         0,           0, 1]
])
R1_2 = np.array(
    [[np.cos(T2), -np.sin(T2), 0],
    [np.sin(T2),  np.cos(T2), 0], 
    [         0,           0, 1]
])


R0_2 = np.dot(R0_1, R1_2)
R0_2 = np.ndarray.round(R0_2, E)

V = [1, 0, 0]
U = np.dot(V, R0_2)
U = np.ndarray.round(U, E)
print(U)
#=======================================================
# Data Visualization
fig = plt.figure("Unit Sphere Chart", figsize=(12, 9))
ax = fig.gca(projection='3d')
ax.set_aspect("equal")
plt.title("Unit Sphere Chart"); 

# draw a point
ax.scatter([0], [0], [0], color="g", s=100)
ax.scatter([1], [0], [0], color="k", s=0)
ax.scatter([-1], [0], [0], color="k", s=0)
ax.scatter([0], [1], [0], color="k", s=0)
ax.scatter([0], [-1], [0], color="k", s=0)
ax.scatter([0], [0], [1], color="k", s=0)
ax.scatter([0], [0], [-1], color="k", s=0)

ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')

# draw a vector
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d

class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        FancyArrowPatch.__init__(self, (0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs
    def draw(self, renderer):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, renderer.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        FancyArrowPatch.draw(self, renderer)

a = Arrow3D([0, 1], [0, 0], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(a)
c = Arrow3D([0, -1], [0, 0], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(c)
d = Arrow3D([0, 0], [0, 1], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(d)
e = Arrow3D([0, 0], [0, -1], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(e)
f = Arrow3D([0, 0], [0, 0], [0, -1], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(f)
g = Arrow3D([0, 0], [0, 0], [0, 1], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(g)

ax.text(V[0]+0.05,V[1]+0.05,V[2]+0.05,  '%s' % "V"+str(V), size=12, zorder=1,  color='r')
ht = Arrow3D([0, V[0]], [0, V[1]], [0, V[2]], mutation_scale=20,
            lw=3, arrowstyle="-|>", color="r")
ax.add_artist(ht)
ax.text(U[0]+0.05,U[1]+0.05,U[2]+0.05,  '%s' % "U"+str(U), size=12, zorder=1,  color='b')
hb = Arrow3D([0, U[0]], [0, U[1]], [0, U[2]], mutation_scale=20,
            lw=3, arrowstyle="-|>", color="b")
ax.add_artist(hb)
plt.show()