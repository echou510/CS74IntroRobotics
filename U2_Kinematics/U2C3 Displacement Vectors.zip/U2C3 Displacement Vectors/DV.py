import numpy as np


T1=90   # Theta 1 angle in degree
T2=45    # Theta 2 angle in degree

T1 = (T1/180.0)*np.pi
T2 = (T2/180.0)*np.pi

a1 = 1 # link length a1
a2 = 1 # link length a2
a3 = 1 # link length a3
a4 = 1 # link length a4

d0_1 = [ a2 * np.cos(T1), a2* np.sin(T1), a1]
d0_1 = np.array(d0_1)
d0_1 = d0_1.reshape(3, 1)
print(d0_1)

d1_2 = [ a4 * np.cos(T2), a4* np.sin(T2), a3]
d1_2 = np.array(d1_2)
d1_2 = d1_2.reshape(3, 1)
print(d1_2)





