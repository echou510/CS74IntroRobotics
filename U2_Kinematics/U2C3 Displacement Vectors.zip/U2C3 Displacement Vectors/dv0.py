import numpy as np
import pprint

T1=90   # Theta 1 angle in degree
T2=90   # Theta 2 angle in degree

T1 = (T1/180.0)*np.pi
T2 = (T2/180.0)*np.pi

d = [1, 2, 3]

print(d)

d1 =[[1], 
     [2],
     [3]
    ]
d1 = np.matrix(d1)
print(d1)

d2 = np.array(d)
d2 = d2.reshape(3, 1)
print(d2)



