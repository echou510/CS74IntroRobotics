# differential.py
# author: Dr. Eric Y. Chou
# version: 09/16/2020
#
import numpy as np
E = 10   # round of 10 decimal points

D = [[0, -2, 0, 2],
     [2,  0, 0, 2],
     [0,  0, 0, 0],
     [0,  0, 0, 0],
     ]

D = np.array(D)
D = D.reshape(4, 4)
D = np.ndarray.round(D, E)
print("D:")
print(D)
print()

T = [[1,  0, 0, 2],
     [0,  1, 0, 3],
     [0,  0, 1, 0],
     [0,  0, 0, 1],
     ]
T = np.array(T)
T = T.reshape(4, 4)
T = np.ndarray.round(T, E)
print("T:")
print(T)
print()

DT = np.dot(D, T)
DT = np.ndarray.round(DT, E)
print("DT:")
print(DT)
print()

w = [3, 5, 0, 1]
w = np.array(w)
w = w.reshape(4, 1)
print("w:")
print(w)
print()

Tw = np.dot(T, w)
DTw = np.dot(D, Tw)
DTw = np.ndarray.round(DTw, E)
print("DTw:")
print(DTw)
print()

