import numpy as np
from pylab import *

t = linspace(0, 2.0*np.pi, 201)
w = 2   # radians / sec
x = [np.cos(w * t[i]) for i in range(len(t))]
y = [np.sin(w * t[i]) for i in range(len(t))]

fig, (plot1, plot2, plot3) = subplots(3)
plot1.plot(t, x, 'tab:orange')
plot2.plot(t, y, 'tab:green')
plot3.scatter(x, y)
show()