import numpy as np
from pylab import *
E = 10

def derivative(f, w, t, h):
    return (f(w*(t+h))-f(w*t))/h

t = linspace(0, 2.0*np.pi, 201)
w = 2   # radians / sec
h = 10**(-E)

x = [np.cos(w * i) for i in t]
dxdt = [derivative(np.cos, w, t[i], h) for i in range(len(t))]
y = [np.sin(w * i) for i in t]
dydt = [derivative(np.sin, w, t[i], h) for i in range(len(t))]

fig, (plot1, plot2, plot3, plot4) = subplots(4)
plot1.plot(t, x, 'orange')
plot2.plot(t, dxdt, 'purple')
plot3.plot(t, y, 'green')
plot4.plot(t, dydt, 'blue')
show()