import numpy as np
from pylab import *
E = 3
h = 10**(-E)

def integral(f, w, c, a, b, h):
    y = [c]                                # initial value
    lenx = int((b-a)/h)
    intf = c
    t = a
    for i in range(lenx-1):                # integral engine
        intf0 = intf
        intf  = intf0 + f(w*t)*h
        t += h
        y.append(intf)
    return y

a = 0
b = np.pi*2
t = np.linspace(a, b, int((b-a)/h))
w = 2   # radians / sec
x = [np.cos(w*t[i]) for i in range(len(t))]
intx = integral(np.cos, w, 0, a, b, h)
y = [np.sin(w*t[i]) for i in range(len(t))]
inty = integral(np.sin, w, -0.5, a, b, h)

fig, (plot1, plot2, plot3, plot4) = subplots(4)
plot1.plot(t, x, 'orange')
plot2.plot(t, intx, 'purple')
plot3.plot(t, y, 'green')
plot4.plot(t, inty, 'blue')
show()