import numpy as np 

E = 2

x = np.array([[1,3],[2,1]]) 
y = np.linalg.inv(x) 
y = np.round(y, E)
print("X:")
print(x)
print()
print("Y:")
print(y)
print()
print("I=XY:")
Ix = np.round(np.dot(x,y), E)
print(Ix)
print()
