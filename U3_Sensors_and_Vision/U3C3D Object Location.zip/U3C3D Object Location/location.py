import numpy as np
import cv2
threshold = 63

def getGrayImage(f):
    w = f.shape[1]
    h = f.shape[0]
    img = np.zeros((h, w), dtype=np.uint8)

    for i in range(h):
        for j in range(w):
            g = 0.299*f[i][j][2]+0.587*f[i][j][1]+0.144*f[i][j][0]
            if (g>=255): g=255
            gray = np.uint8(g)
            img[i][j] = gray
    return img

def getBlackWhite(f):
    w = f.shape[1]
    h = f.shape[0]
    img = np.zeros((h, w), dtype=np.uint8)

    for i in range(h):
        for j in range(w):
            g = 255 if (f[i][j] >=threshold) else 0
            img[i][j] = np.uint8(g)
    contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    _ = cv2.drawContours(color, contours, -1, (255, 0, 0), 2)
    return img, color
# start a camera
cam = cv2.VideoCapture(0)

# frame capturing loop
while True:
    _, frame = cam.read()
    cv2.imshow("Original", frame)
    gray = getGrayImage(frame)
    cv2.imshow("Gray", gray)
    bw, color = getBlackWhite(gray)
    cv2.imshow("BW", bw)
    cv2.imshow("Color", color)

    key = cv2.waitKey(100)
    if key == 27: # Esc
        break
cv2.destroyAllWindows()




