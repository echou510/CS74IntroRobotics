import numpy as np
import cv2
import copy

def copyImage(f):
    g = copy.copy(f)
    return g

def allRedImage(f):
    redImage = copyImage(f)
    for i in range(len(redImage)):
        for j in range(len(redImage[0])):
            redImage[i][j][1] = 0
            redImage[i][j][0] = 0
    return redImage

def allGreenImage(f):
    greenImage = copyImage(f)
    for i in range(len(greenImage)):
        for j in range(len(greenImage[0])):
            greenImage[i][j][2] = 0
            greenImage[i][j][0] = 0
    return greenImage

def allBlueImage(f):
    blueImage = copyImage(f)
    for i in range(len(blueImage)):
        for j in range(len(blueImage[0])):
            blueImage[i][j][2] = 0
            blueImage[i][j][1] = 0
    return blueImage

def getGrayImage(f):
    grayImage = copyImage(f)
    for i in range(len(grayImage)):
        for j in range(len(grayImage[0])):
            g = 0.299*f[i][j][2]+0.587*f[i][j][1]+0.144*f[i][j][0]
            if (g>=255): g=255
            gray = np.uint8(g)
            grayImage[i][j][2] = gray
            grayImage[i][j][1] = gray
            grayImage[i][j][0] = gray
    return grayImage

# start a camera
cam = cv2.VideoCapture(0)

# frame capturing loop
while True:
    _, frame = cam.read()
    cv2.imshow("Figure 1", frame)
    # new frame is here.
    red = frame[:, :, 2]
    green = frame[:, :, 1]
    blue = frame[:, :, 0]
    key = cv2.waitKey(5)
    if key == 27: # Esc
        break
cv2.destroyAllWindows()

# print out the frame
cv2.imshow("full color", frame)

# get image with only red channel
redImage = allRedImage(frame)
cv2.imshow("red", redImage)

greenImage = allGreenImage(frame)
cv2.imshow("green", greenImage)

blueImage = allBlueImage(frame)
cv2.imshow("blue", blueImage)

grayImage = getGrayImage(frame)
cv2.imshow("gray", grayImage)


