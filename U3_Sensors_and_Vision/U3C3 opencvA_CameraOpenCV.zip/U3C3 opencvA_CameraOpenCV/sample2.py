import numpy as np
import cv2
# start a camera
cam = cv2.VideoCapture(0)

# frame capturing loop
while True:
    _, frame = cam.read()
    cv2.imshow("Figure 1", frame)
    # new frame is here.
    key = cv2.waitKey(5)
    if key == 27:
        break
cv2.destroyAllWindows()

# print out the frame
print(frame)
print(frame.shape)
print(frame[0][0])
