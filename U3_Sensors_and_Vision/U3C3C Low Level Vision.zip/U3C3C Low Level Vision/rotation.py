import cv2

image = cv2.imread("messi.jpg")
cv2.imshow("Original", image)
(h, w) = image.shape[:2]
center = (w // 2, h // 2)
matrix = cv2.getRotationMatrix2D(center, 60, 1.0)
rotated = cv2.warpAffine(image, matrix, (w, h))
cv2.imshow("Rotated by 60 Degrees", rotated)
matrix = cv2.getRotationMatrix2D(center, -90, 1.0)
rotated = cv2.warpAffine(image, matrix, (w, h))
cv2.imshow("Rotated by -90 Degrees", rotated)

while True:
    if cv2.waitKey(100) == 27: break
cv2.destroyAllWindows()