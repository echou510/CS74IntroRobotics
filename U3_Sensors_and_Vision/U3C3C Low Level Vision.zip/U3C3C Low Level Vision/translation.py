import cv2
import numpy as np

image = cv2.imread("messi.jpg")
cv2.imshow("Original", image)
translation_matrix = np.float32([[1, 0, 25], [0, 1, 50]])
shifted = cv2.warpAffine(image, translation_matrix, (image.shape[1], image.shape[0]))
cv2.imshow("Shifted Down and Right", shifted)

M = np.float32([[1, 0, -50], [0, 1, -90]])
shifted = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]))
cv2.imshow("Shifted Up and Left", shifted)

while True:
    if cv2.waitKey(100) == 27: break
cv2.destroyAllWindows()