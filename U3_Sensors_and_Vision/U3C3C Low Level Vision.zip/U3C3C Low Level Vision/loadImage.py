import cv2
image =cv2.imread("messi.jpg")
cv2.imshow("Image", image)

while True:
    if cv2.waitKey(100) == 27: break
cv2.destroyAllWindows()
